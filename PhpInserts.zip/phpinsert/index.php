<?php


$conn = mysqli_connect ("localhost", "root", "", "pizza");

$affectedRow = 0;

$xml = simplexml_load_file ("pizza_toppings.xml")
    or die ("Error: Cannot create object");


foreach ($xml->children () as $row) {
    $topping_id = $row -> topping_id;
    $topping_names = $row -> topping_name;

$sql = "INSERT INTO pizza_toppings (topping_id, topping_names) VALUES ('" 
    . $topping_id . "' , '" . $topping_names .   "')";

$result = mysqli_query ($conn, $sql);

if (! empty ($result)) {
    $affectedRow ++;
} else {
    $error_message = mysqli_error ($conn) . "\n";
}
}
?>

<?php
if ($affectedRow > 0) {
$message = $affectedRow. " records inserted";
} else {
$message = "No records inserted";
}

?>


<div class="affected-row">
    <?php echo $message; ?>
</div

<?php if (! empty ($error_message)) { ?>

<div class="error-message">
    <?php echo  ($error_message) ; ?>
</div>
<?php } ?>